Beneath a Steel Sky, Floppy                   (C) Revolution Software Ltd 1993-
------------------------------                ---------------------------------
                                                             
The Legal Stuff:

Preamble:
  Basically, give this game away, share it with your friends. Don't remove this
Readme, or pretend you wrote it. You can include it in a software collection,
like a linux distribution or coverdisk (which may be sold), but using it in
things like commercial adventure game collections without asking is just playing
dirty. This preamble is not legally binding, but is to clarify the intent of the
following license.

License:
 1) You may distribute this game for free on any medium, provided this readme
and all associated copyright notices and disclaimers are left intact.

 2) You may charge a reasonable copying fee for this archive, and may distribute
it in aggregate as part of a larger & possibly commercial software distribution
(such as a Linux distribution or magazine coverdisk). You must provide proper
attribution and ensure this readme and all associated copyright notices, and
disclaimers are left intact.

 3) You may not charge a fee for the game itself. This includes reselling the
game as an individual item.

4) All game content is (C) Revolution Software Ltd.

5) THE GAMEDATA IN THIS ARCHIVE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING AND NOT LIMITED TO ANY IMPLIED WARRANTIES OF
MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
